﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace Evidence_Knih
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }

}
