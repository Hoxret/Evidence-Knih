﻿using System;
using System.Collections.ObjectModel;
using System.IO;
using System.Text.Json;
using Evidence_Knih.Models;

namespace Evidence_Knih.Services
{
    public class DataService
    {
        private readonly string _filePath;

        public DataService()
        {
            var dir = AppContext.BaseDirectory;
            _filePath = Path.Combine(dir, "games.json");
        }

        public ObservableCollection<Game> Load()
        {
            try
            {
                if (!File.Exists(_filePath))
                    return new ObservableCollection<Game>();

                var json = File.ReadAllText(_filePath);
                var options = new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true,
                    ReadCommentHandling = JsonCommentHandling.Skip,
                    AllowTrailingCommas = true
                };

                var items = JsonSerializer.Deserialize<ObservableCollection<Game>>(json, options);
                return items ?? new ObservableCollection<Game>();
            }
            catch
            {
                // Při chybě načítání vrátíme prázdnou kolekci (možno rozšířit o logování)
                return new ObservableCollection<Game>();
            }
        }

        public void Save(ObservableCollection<Game> games)
        {
            try
            {
                var options = new JsonSerializerOptions { WriteIndented = true };
                var json = JsonSerializer.Serialize(games, options);
                File.WriteAllText(_filePath, json);
            }
            catch
            {
                // Chyby ukládání ignorujeme pro jednoduchost; při potřebě přidejte logování nebo UI hlášku
            }
        }

        public int GetNextId(ObservableCollection<Game> games)
        {
            int max = 0;
            foreach (var g in games)
            {
                if (g.ID > max) max = g.ID;
            }
            return max + 1;
        }
    }
}