﻿using System.ComponentModel;

namespace Evidence_Knih.Models
{
    public class Game : INotifyPropertyChanged
    {
        private int _id;
        private string _nazev = string.Empty;
        private string _vyvojar = string.Empty;
        private int _rokVydani;
        private string _zanr = string.Empty;
        private int _pocetHodin;
        private bool _vlastnim;

        public int ID
        {
            get => _id;
            set { if (_id != value) { _id = value; OnPropertyChanged(nameof(ID)); } }
        }

        public string Nazev
        {
            get => _nazev;
            set { if (_nazev != value) { _nazev = value; OnPropertyChanged(nameof(Nazev)); } }
        }

        public string Vyvojar
        {
            get => _vyvojar;
            set { if (_vyvojar != value) { _vyvojar = value; OnPropertyChanged(nameof(Vyvojar)); } }
        }

        public int RokVydani
        {
            get => _rokVydani;
            set { if (_rokVydani != value) { _rokVydani = value; OnPropertyChanged(nameof(RokVydani)); } }
        }

        public string Zanr
        {
            get => _zanr;
            set { if (_zanr != value) { _zanr = value; OnPropertyChanged(nameof(Zanr)); } }
        }

        public int PocetHodin
        {
            get => _pocetHodin;
            set { if (_pocetHodin != value) { _pocetHodin = value; OnPropertyChanged(nameof(PocetHodin)); } }
        }

        public bool Vlastnim
        {
            get => _vlastnim;
            set { if (_vlastnim != value) { _vlastnim = value; OnPropertyChanged(nameof(Vlastnim)); } }
        }

        public event PropertyChangedEventHandler? PropertyChanged;
        protected void OnPropertyChanged(string name) => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));

        public Game Clone() => new Game
        {
            ID = ID,
            Nazev = Nazev,
            Vyvojar = Vyvojar,
            RokVydani = RokVydani,
            Zanr = Zanr,
            PocetHodin = PocetHodin,
            Vlastnim = Vlastnim
        };
    }
}