﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using Evidence_Knih.Models;
using Evidence_Knih.Services;

namespace Evidence_Knih
{
    public partial class MainWindow : Window
    {
        private readonly DataService _dataService;
        private ObservableCollection<Game> Hry { get; set; } = new ObservableCollection<Game>();
        private ICollectionView? _view;

        public MainWindow()
        {
            InitializeComponent();

            _dataService = new DataService();
            Hry = _dataService.Load();
            dgHry.ItemsSource = Hry;

            _view = CollectionViewSource.GetDefaultView(Hry);
            _view.Filter = null;

            var searchControl = this.FindName("txtHledat") as TextBox;
            if (searchControl != null)
                searchControl.TextChanged += (_, __) => ApplyFilter(searchControl.Text);

            this.Closing += (_, __) => _dataService.Save(Hry);
        }

        private void ApplyFilter(string? text)
        {
            if (_view == null) return;

            if (string.IsNullOrWhiteSpace(text))
            {
                _view.Filter = null;
            }
            else
            {
                var t = text.Trim().ToLowerInvariant();
                _view.Filter = item =>
                {
                    if (item is Game g)
                    {
                        return (g.Nazev?.ToLowerInvariant().Contains(t) == true)
                            || (g.Vyvojar?.ToLowerInvariant().Contains(t) == true)
                            || (g.Zanr?.ToLowerInvariant().Contains(t) == true)
                            || g.RokVydani.ToString().Contains(t);
                    }
                    return false;
                };
            }
            _view.Refresh();
        }

        private void BtnPridat_Click(object sender, RoutedEventArgs e)
        {
            var result = ShowAddEditDialog(null);
            if (result != null)
            {
                result.ID = _dataService.GetNextId(Hry);
                Hry.Add(result);
                _dataService.Save(Hry);
                _view?.Refresh();
                dgHry.SelectedItem = result;
                dgHry.ScrollIntoView(result);
            }
        }

        private void BtnUpravit_Click(object sender, RoutedEventArgs e)
        {
            if (dgHry.SelectedItem is not Game selected)
            {
                MessageBox.Show("Vyberte hru k úpravě.", "Informace", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            var edited = ShowAddEditDialog(selected);
            if (edited != null)
            {
                selected.Nazev = edited.Nazev;
                selected.Vyvojar = edited.Vyvojar;
                selected.RokVydani = edited.RokVydani;
                selected.Zanr = edited.Zanr;
                selected.PocetHodin = edited.PocetHodin;
                selected.Vlastnim = edited.Vlastnim;

                _dataService.Save(Hry);
                _view?.Refresh();
            }
        }

        private void BtnSmazat_Click(object sender, RoutedEventArgs e)
        {
            if (dgHry.SelectedItem is not Game selected)
            {
                MessageBox.Show("Vyberte hru ke smazání.", "Informace", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            var result = MessageBox.Show($"Opravdu smazat hru \"{selected.Nazev}\"?", "Potvrzení", MessageBoxButton.YesNo, MessageBoxImage.Question);
            if (result == MessageBoxResult.Yes)
            {
                Hry.Remove(selected);
                _dataService.Save(Hry);
                _view?.Refresh();
            }
        }

        // Programově vytvořený dialog pro přidání / úpravu hry — nepotřebujete samostatný .xaml soubor
        private Game? ShowAddEditDialog(Game? source)
        {
            var dlg = new Window
            {
                Title = source == null ? "Přidat hru" : "Upravit hru",
                Owner = this,
                WindowStartupLocation = WindowStartupLocation.CenterOwner,
                SizeToContent = SizeToContent.WidthAndHeight,
                ResizeMode = ResizeMode.NoResize,
                MinWidth = 420,
                Content = null
            };

            var grid = new Grid { Margin = new Thickness(10) };
            for (int i = 0; i < 8; i++) grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(110) });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            // Controls
            TextBox tbNazev = AddLabeledTextBox(grid, 0, "Název:");
            TextBox tbVyvojar = AddLabeledTextBox(grid, 1, "Vývojář:");
            TextBox tbRok = AddLabeledTextBox(grid, 2, "Rok vydání:");
            TextBox tbZanr = AddLabeledTextBox(grid, 3, "Žánr:");
            TextBox tbHodiny = AddLabeledTextBox(grid, 4, "Počet hodin:");
            CheckBox cbVlastnim = new CheckBox { Margin = new Thickness(6, 8, 0, 0), VerticalAlignment = VerticalAlignment.Center, Content = "Vlastním" };
            Grid.SetRow(cbVlastnim, 5);
            Grid.SetColumn(cbVlastnim, 1);
            grid.Children.Add(cbVlastnim);

            var spButtons = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right, Margin = new Thickness(0, 12, 0, 0) };
            var btnOk = new Button { Content = "OK", Width = 90, Margin = new Thickness(0, 0, 8, 0) };
            var btnCancel = new Button { Content = "Storno", Width = 90 };
            spButtons.Children.Add(btnOk);
            spButtons.Children.Add(btnCancel);
            Grid.SetRow(spButtons, 7);
            Grid.SetColumnSpan(spButtons, 2);
            grid.Children.Add(spButtons);

            // naplnit při editaci
            if (source != null)
            {
                tbNazev.Text = source.Nazev;
                tbVyvojar.Text = source.Vyvojar;
                tbRok.Text = source.RokVydani > 0 ? source.RokVydani.ToString() : string.Empty;
                tbZanr.Text = source.Zanr;
                tbHodiny.Text = source.PocetHodin.ToString();
                cbVlastnim.IsChecked = source.Vlastnim;
            }

            btnOk.Click += (_, __) =>
            {
                // validace
                var nazev = tbNazev.Text.Trim();
                var vyvojar = tbVyvojar.Text.Trim();
                if (string.IsNullOrEmpty(nazev))
                {
                    MessageBox.Show("Název nesmí být prázdný.", "Chyba", MessageBoxButton.OK, MessageBoxImage.Warning);
                    tbNazev.Focus();
                    return;
                }

                if (string.IsNullOrEmpty(vyvojar))
                {
                    MessageBox.Show("Vývojář nesmí být prázdný.", "Chyba", MessageBoxButton.OK, MessageBoxImage.Warning);
                    tbVyvojar.Focus();
                    return;
                }

                if (!int.TryParse(tbRok.Text.Trim(), out int rok) || rok <= 0 || rok > DateTime.Now.Year)
                {
                    MessageBox.Show($"Rok vydání musí být celé číslo 1..{DateTime.Now.Year}.", "Chyba", MessageBoxButton.OK, MessageBoxImage.Warning);
                    tbRok.Focus();
                    return;
                }

                if (!int.TryParse(tbHodiny.Text.Trim(), out int hodiny) || hodiny < 0)
                {
                    MessageBox.Show("Počet hodin musí být celé nezáporné číslo.", "Chyba", MessageBoxButton.OK, MessageBoxImage.Warning);
                    tbHodiny.Focus();
                    return;
                }

                Game resultGame = source?.Clone() ?? new Game();
                resultGame.Nazev = nazev;
                resultGame.Vyvojar = vyvojar;
                resultGame.RokVydani = rok;
                resultGame.Zanr = tbZanr.Text.Trim();
                resultGame.PocetHodin = hodiny;
                resultGame.Vlastnim = cbVlastnim.IsChecked == true;

                dlg.Tag = resultGame;
                dlg.DialogResult = true;
                dlg.Close();
            };

            btnCancel.Click += (_, __) =>
            {
                dlg.DialogResult = false;
                dlg.Close();
            };

            dlg.Content = grid;
            var show = dlg.ShowDialog();
            if (show == true && dlg.Tag is Game g) return g;
            return null;
        }

        // Pomocná rutina pro přidání popisku + TextBoxu do gridu
        private static TextBox AddLabeledTextBox(Grid grid, int row, string label)
        {
            var tbLabel = new TextBlock { Text = label, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0, 4, 0, 0) };
            Grid.SetRow(tbLabel, row);
            Grid.SetColumn(tbLabel, 0);
            grid.Children.Add(tbLabel);

            var tb = new TextBox { Margin = new Thickness(6, 2, 0, 0), Width = 250 };
            Grid.SetRow(tb, row);
            Grid.SetColumn(tb, 1);
            grid.Children.Add(tb);

            return tb;
        }
    }
}